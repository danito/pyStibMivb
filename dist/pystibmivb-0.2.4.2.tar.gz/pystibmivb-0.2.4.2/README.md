# pyStibMivb
A python wrapper for the m.stib.be api

Aknowledgements:
Freely inspired by [pyRail](https://gitlab.com/tjorim/pyrail)
